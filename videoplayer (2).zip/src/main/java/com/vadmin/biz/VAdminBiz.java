package com.vadmin.biz;

import com.vadmin.entity.VAdmin;

public interface VAdminBiz {
    public VAdmin login(String aname,String apwd);
    public VAdmin findAdminByName(String aname);
}
