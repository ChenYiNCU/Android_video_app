package com.vadmin.biz.impl;

import com.vadmin.biz.VAdminBiz;
import com.vadmin.entity.VAdmin;
import com.vadmin.mapper.VAdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("vAdminBiz")
public class VAdminBizImpl implements VAdminBiz {
    @Autowired
    private VAdminMapper vAdminMapper;

    @Override
    public VAdmin login(String aname, String apwd) {
        return vAdminMapper.login(aname,apwd);
    }

    @Override
    public VAdmin findAdminByName(String aname) {
        return vAdminMapper.findAdminByName(aname);
    }
}
