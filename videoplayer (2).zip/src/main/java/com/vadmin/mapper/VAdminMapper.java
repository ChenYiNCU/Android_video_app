package com.vadmin.mapper;

import com.vadmin.entity.VAdmin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface VAdminMapper {
    //用户登陆
    public VAdmin login(@Param("aname") String aname, @Param("apwd") String apwd);
    //判断是否存在该用户名
    public VAdmin findAdminByName(String aname);
}
