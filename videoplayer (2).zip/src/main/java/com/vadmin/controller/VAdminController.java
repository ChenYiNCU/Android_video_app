package com.vadmin.controller;

import com.pojo.ResultDTO;
import com.vadmin.biz.VAdminBiz;
import com.vadmin.entity.VAdmin;
import com.vuser.entity.VUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("vadmin")
public class VAdminController {
    @Autowired
    private VAdminBiz vAdminBiz;

    @RequestMapping(value ="/login")
    @ResponseBody
    public ResultDTO<VAdmin> login(@RequestBody VAdmin vAdmin){
        System.out.println("前台发送过来的User："+vAdmin.toString());
        ResultDTO<VAdmin> vAdminResultDTO=new ResultDTO<>();

        String aname=vAdmin.getAname();
        String apwd=vAdmin.getApwd();
        VAdmin admin1=vAdminBiz.login(aname,apwd);
        VAdmin admin2=vAdminBiz.findAdminByName(aname);
        if(admin2!=null){ //user2！=null  说明当前输入用户名存在
            if(admin1!=null){  //用户名密码都正确
                vAdminResultDTO.setCode(1001);
                vAdminResultDTO.setMsg("登陆成功！");
                vAdminResultDTO.setData(admin1);
            }else{   //用户名正确 密码错误
                vAdminResultDTO.setCode(1003);
                vAdminResultDTO.setMsg("输入密码不正确！");
            }
        }else{ //说明当前输入用户名不存在
            vAdminResultDTO.setCode(1002);
            vAdminResultDTO.setMsg("当前管理员名不存在！");
        }
        return vAdminResultDTO;
    }
}
