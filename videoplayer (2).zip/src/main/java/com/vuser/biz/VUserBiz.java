package com.vuser.biz;

import com.vuser.entity.VUser;

import java.util.List;

public interface VUserBiz {
    public VUser login(String uname, String upwd);
    public VUser findUserByName(String uname);
    public void regist(VUser vUser);
    public void update(VUser vUser);
    public void update2(VUser vUser);
    public void update3(VUser vUser);
    public void update4(VUser vUser);
    public VUser findUserById(int id);
    public void updatePwd(VUser vUser);
    public List<VUser> findAll();
    public void deleteByName(String uname);
}
