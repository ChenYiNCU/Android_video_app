package com.vuser.biz.impl;

import com.vuser.biz.VUserBiz;
import com.vuser.entity.VUser;
import com.vuser.mapper.VUserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("vUserBiz")
public class VUserBizImpl implements VUserBiz {
    @Autowired
    private VUserMapper vUserMapper;

    @Override
    public VUser login(String uname, String upwd) {
        VUser vUser=vUserMapper.login(uname,upwd);
        return vUser;
    }

    @Override
    public VUser findUserByName(String uname) {
        VUser vUser=vUserMapper.findUserByName(uname);
        return vUser;
    }

    @Override
    public void regist(VUser vUser) {
        vUserMapper.regist(vUser);
    }

    @Override
    public void update(VUser vUser) {
        vUserMapper.update(vUser);
    }

    @Override
    public void update2(VUser vUser) {
        vUserMapper.update2(vUser);
    }

    @Override
    public void update3(VUser vUser) {
        vUserMapper.update3(vUser);
    }

    @Override
    public void update4(VUser vUser) {
        vUserMapper.update4(vUser);
    }

    @Override
    public VUser findUserById(int id) {
        return vUserMapper.findUserById(id);
    }

    @Override
    public void updatePwd(VUser vUser) {
        vUserMapper.updatePwd(vUser);
    }

    @Override
    public List<VUser> findAll() {
        List<VUser> list= vUserMapper.findAll();
        return list;
    }

    @Override
    public void deleteByName(String uname) {
        vUserMapper.deleteByName(uname);
    }
}
