package com.vuser.mapper;

import com.vuser.entity.VUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VUserMapper {
    //用户登陆
    public VUser login(@Param("uname") String uname,@Param("upwd") String upwd);
    //判断是否存在该用户名
    public VUser findUserByName(String uname);
    //用户注册
    public void regist(VUser vUser);
    //修改用户信息
    public void update(VUser vUser);
    //修改用户信息  不修改头像
    public void update2(VUser vUser);
    //修改用户信息 管理员带修改密码
    public void update3(VUser vUser);
    //修改用户信息 不修改头像 管理员带密码
    public void update4(VUser vUser);
    //根据id查找用户
    public VUser findUserById(int id);
    //修改密码
    public void updatePwd(VUser vUser);
    //查询所有用户
    public List<VUser> findAll();
    //根据用户名删除用户
    public void deleteByName(String uname);
}
