package com.vuser.controller;

import com.pojo.ResultDTO;
import com.util.UploadUtil;
import com.vuser.biz.VUserBiz;
import com.vuser.entity.VUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("vuser")
public class VUserController {
    @Autowired
    private VUserBiz vUserBiz;

    @RequestMapping(value ="/test")
    @ResponseBody
    public ResultDTO<VUser> testDoGetNoData()throws Exception{
        VUser user = new VUser();
        //以下代码可以在Service中呈现  本案例暂不处理
        ResultDTO<VUser> userResultDTO = new ResultDTO<>();
        userResultDTO.setCode(1001);
        userResultDTO.setMsg("发送成功");
        //重构后台发送回的响应数据（模拟数据变化）
        user.setUname("admin");
        user.setUpwd("admin");
        userResultDTO.setData(user);
        List<VUser> users = new ArrayList<>();
        users.add(user);
        VUser user2 = new VUser();
        user2.setUname("Tom");
        user2.setUpwd("jerry");
        users.add(user2);
        userResultDTO.setDatas(users);
        return userResultDTO;
    }

    @RequestMapping(value ="/login")
    @ResponseBody
    public ResultDTO<VUser> login(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();

        String uname=vUser.getUname();
        String upwd=vUser.getUpwd();
        VUser user1=vUserBiz.login(uname,upwd);
        VUser user2=vUserBiz.findUserByName(uname);
        if(user2!=null){ //user2！=null  说明当前输入用户名存在
            if(user1!=null){  //用户名密码都正确
                vUserResultDTO.setCode(1001);
                vUserResultDTO.setMsg("登陆成功！");
                vUserResultDTO.setData(user1);
            }else{   //用户名正确 密码错误
                vUserResultDTO.setCode(1003);
                vUserResultDTO.setMsg("输入密码不正确！");
            }
        }else{ //说明当前输入用户名不存在
            vUserResultDTO.setCode(1002);
            vUserResultDTO.setMsg("当前用户名不存在！");
        }
        return vUserResultDTO;
    }

    @RequestMapping(value ="/regist")
    @ResponseBody
    public ResultDTO<VUser> regist(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        String uname=vUser.getUname();
        String upwd=vUser.getUpwd();
        String usex=vUser.getUsex();
        int uage=vUser.getUage();
        String utel=vUser.getUtel();
        String uimg=vUser.getUimg();
        VUser user=new VUser();
        user.setUname(uname);
        user.setUpwd(upwd);
        user.setUsex(usex);
        user.setUage(uage);
        user.setUtel(utel);
        user.setUimg(uimg);
        vUserBiz.regist(user);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("注册成功！");
        return vUserResultDTO;
    }

    @RequestMapping(value ="/findUserByName")
    @ResponseBody
    public ResultDTO<VUser> findUserByName(@RequestBody VUser vUser){
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        String uname=vUser.getUname();
        VUser user=new VUser();
        if(uname==null || uname=="" || uname.isEmpty()){
            vUserResultDTO.setCode(1003);
            vUserResultDTO.setMsg("用户名为空");
        }else{
            user=vUserBiz.findUserByName(uname);
            if(user==null || user.getUname()==uname){
                vUserResultDTO.setCode(1001);
                vUserResultDTO.setMsg("用户名可用");
            }else{
                vUserResultDTO.setCode(1002);
                vUserResultDTO.setMsg("用户名已存在");
                vUserResultDTO.setData(user);
            }
        }
        return vUserResultDTO;
    }

    @RequestMapping(value ="/UploadOnePic")
    @ResponseBody
    public ResultDTO<VUser> testUploadOnePic(MultipartFile file, HttpServletRequest request)throws Exception{
        //String imageMainUrl = UploadUtil.uploadOneFile(file,"D://upload//okHttpDemo//",request,"test");  F://upload//videoplayer//
        String imageMainUrl = UploadUtil.uploadOneFile(file,"F://upload//videoplayer//",request,"test");
        ResultDTO<VUser> userResultDTO = new ResultDTO<>();
        userResultDTO.setMsg(imageMainUrl);
        return userResultDTO;
    }

    @RequestMapping(value ="/update")
    @ResponseBody
    public ResultDTO<VUser> update(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        int id=vUser.getId();
        String uname=vUser.getUname();
        String usex=vUser.getUsex();
        int uage=vUser.getUage();
        String utel=vUser.getUtel();
        String uimg=vUser.getUimg();
        VUser user=new VUser();
        user.setId(id);
        user.setUname(uname);
        user.setUsex(usex);
        user.setUage(uage);
        user.setUtel(utel);
        user.setUimg(uimg);
        vUserBiz.update(user);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("修改成功！");
        return vUserResultDTO;
    }

    @RequestMapping(value ="/update2")
    @ResponseBody
    public ResultDTO<VUser> update2(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        int id=vUser.getId();
        String uname=vUser.getUname();
        String usex=vUser.getUsex();
        int uage=vUser.getUage();
        String utel=vUser.getUtel();
        VUser user=new VUser();
        user.setId(id);
        user.setUname(uname);
        user.setUsex(usex);
        user.setUage(uage);
        user.setUtel(utel);
        vUserBiz.update2(user);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("修改成功！");
        return vUserResultDTO;
    }

    @RequestMapping(value ="/update3")
    @ResponseBody
    public ResultDTO<VUser> update3(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        int id=vUser.getId();
        String uname=vUser.getUname();
        String upwd=vUser.getUpwd();
        String usex=vUser.getUsex();
        int uage=vUser.getUage();
        String utel=vUser.getUtel();
        String uimg=vUser.getUimg();
        VUser user=new VUser();
        user.setId(id);
        user.setUname(uname);
        user.setUpwd(upwd);
        user.setUsex(usex);
        user.setUage(uage);
        user.setUtel(utel);
        user.setUimg(uimg);
        vUserBiz.update3(user);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("管理员修改成功！");
        return vUserResultDTO;
    }

    @RequestMapping(value ="/update4")
    @ResponseBody
    public ResultDTO<VUser> update4(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        int id=vUser.getId();
        String uname=vUser.getUname();
        String upwd=vUser.getUpwd();
        String usex=vUser.getUsex();
        int uage=vUser.getUage();
        String utel=vUser.getUtel();
        VUser user=new VUser();
        user.setId(id);
        user.setUname(uname);
        user.setUpwd(upwd);
        user.setUsex(usex);
        user.setUage(uage);
        user.setUtel(utel);
        vUserBiz.update4(user);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("管理员修改成功！");
        return vUserResultDTO;
    }
    @RequestMapping(value ="/findUserById")
    @ResponseBody
    public ResultDTO<VUser> findUserById(@RequestBody VUser vUser){
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        int id=vUser.getId();
        System.out.println(id);
        VUser user=vUserBiz.findUserById(id);
        if(user!=null){
            vUserResultDTO.setCode(1001);
            vUserResultDTO.setMsg("查找成功！");
            vUserResultDTO.setData(user);
            System.out.println(user.toString());
        }
        return vUserResultDTO;
    }

    @RequestMapping(value ="/updatePwd")
    @ResponseBody
    public ResultDTO<VUser> updatePwd(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        int id=vUser.getId();
        String upwd=vUser.getUpwd();
        VUser user=new VUser();
        user.setId(id);
        user.setUpwd(upwd);
        vUserBiz.updatePwd(user);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("修改密码成功！");
        return vUserResultDTO;
    }

    @RequestMapping(value ="/findAll")
    @ResponseBody
    public ResultDTO<VUser> findAll()throws Exception{
        //以下代码可以在Service中呈现  本案例暂不处理
        ResultDTO<VUser> userResultDTO = new ResultDTO<>();
        userResultDTO.setCode(1001);
        userResultDTO.setMsg("发送成功");
        //重构后台发送回的响应数据（模拟数据变化）
        List<VUser> userList = vUserBiz.findAll();
        for(VUser user:userList){
            System.out.println(user.toString());
        }
        userResultDTO.setDatas(userList);
        return userResultDTO;
    }

    @RequestMapping(value ="/deleteByName")
    @ResponseBody
    public ResultDTO<VUser> deleteByName(@RequestBody VUser vUser){
        System.out.println("前台发送过来的User："+vUser.toString());
        ResultDTO<VUser> vUserResultDTO=new ResultDTO<>();
        String uname=vUser.getUname();
        System.out.println("删除用户名："+uname);
        vUserBiz.deleteByName(uname);
        vUserResultDTO.setCode(1001);
        vUserResultDTO.setMsg("删除成功！");
        return vUserResultDTO;
    }
}
