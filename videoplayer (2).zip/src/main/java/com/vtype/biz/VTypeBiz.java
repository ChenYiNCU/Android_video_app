package com.vtype.biz;

public interface VTypeBiz {
}
