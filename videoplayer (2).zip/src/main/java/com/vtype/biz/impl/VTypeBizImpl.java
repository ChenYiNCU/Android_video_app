package com.vtype.biz.impl;

import com.vtype.biz.VTypeBiz;
import com.vtype.mapper.VTypeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("vtypeBiz")
public class VTypeBizImpl implements VTypeBiz {
    @Autowired
    private VTypeMapper vTypeMapper;
}
