package com.video.biz.impl;

import com.video.biz.VideoBiz;
import com.video.entity.Discuss;
import com.video.entity.Video;
import com.video.mapper.VideoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("videoBiz")
public class VideoBizImpl implements VideoBiz {
    @Autowired
    private VideoMapper videoMapper;

//    陈益
    @Override
    public void star(int pid, int vid) {
        videoMapper.star(pid, vid);
    }

    @Override
    public void noStar(int pid, int vid) {
        videoMapper.noStar(pid, vid);
    }

    @Override
    public void setMyscore(int pid, int vid, int score) {
        videoMapper.setMyscore(pid, vid, score);
    }

    @Override
    public int getMyscore(int pid, int vid) {
        try {
            if (videoMapper.getMyscore(pid, vid)>0){
                return videoMapper.getMyscore(pid, vid);
            }
            else {
                return 0;                  //分数最低3.0
            }

        }catch (Exception e){
            return 0;
        }
    }

    @Override
    public double getVscore(int vid) {
        try {
            if (videoMapper.getVscore(vid)>3.0){
                return videoMapper.getVscore(vid);
            }
            else {
                return 3.0;                  //分数最低3.0
            }

        }catch (Exception e){
            return 3.0;
        }

    }

    @Override
    public void updateMyscore(int pid, int vid, int score) {
        videoMapper.updateMyscore(pid, vid, score);
    }

    @Override
    public int isStar(int pid, int vid) {
        return videoMapper.isStar(pid, vid);
    }

    @Override
    public Video findVideoById(int id) {
        return videoMapper.findVideoById(id);
    }

    @Override
    public List<Discuss> getAllWords(int vid) {
        return videoMapper.getAllWords(vid);
    }

    @Override
    public void eva(Discuss discuss) {
        videoMapper.eva(discuss);
    }

    @Override
    public List<Video> getMyStar(int pid) {
        return videoMapper.getMyStar(pid);
    }

//    王晏
@Override
public void add(Video video) {
    videoMapper.add(video);
}

    @Override
    public void update(Video video) {
        videoMapper.update(video);
    }

    @Override
    public List<Video> findAll() {
        return videoMapper.findAll();
    }

    @Override
    public void delete(int id) {
        videoMapper.delete(id);
    }

    @Override
    public Video findById(int id) {
        return videoMapper.findById(id);
    }

    @Override
    public List<Video> findByType(int id) {
        return videoMapper.findByType(id);
    }

    @Override
    public List<Video> search(String src) {
        return videoMapper.search(src);
    }


}
