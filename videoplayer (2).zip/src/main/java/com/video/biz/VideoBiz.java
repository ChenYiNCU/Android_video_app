package com.video.biz;

import com.video.entity.Discuss;
import com.video.entity.Video;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface VideoBiz {
    //    陈益
    public Video findVideoById(int id);
    public int isStar(int pid, int vid);
    public void star(int pid, int vid);       //收藏
    public void noStar(int pid, int vid);     //取消收藏
    public int getMyscore(int pid, int vid);       //获取我的打分
    public void setMyscore(int pid, int vid, int score);
    public void updateMyscore(int pid, int vid, int score);
    public double getVscore(int vid);
    public List<Discuss> getAllWords(int vid);
    public void eva(Discuss discuss);
    public List<Video> getMyStar(int pid);       //获取我所有的收藏

    //王晏
    public void add(Video video);
    public void update(Video video);
    public List<Video> findAll();
    public void delete(int id);
    public Video findById(int id);
    public List<Video> findByType(int id);
    public List<Video> search(String src);

}
