package com.video.mapper;

import com.video.entity.Discuss;
import com.video.entity.Video;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VideoMapper {

//    陈益
    public Video findVideoById(int id);
    public int isStar(@Param("pid") int pid, @Param("vid") int vid);      //用户是否收藏
    public void star(@Param("pid") int pid, @Param("vid") int vid);       //收藏
    public void noStar(@Param("pid") int pid, @Param("vid") int vid);     //取消收藏
    public int getMyscore(@Param("pid") int pid, @Param("vid") int vid);       //获取我的打分
    public void setMyscore(@Param("pid") int pid, @Param("vid") int vid, @Param("score") int score);
    public void updateMyscore(@Param("pid") int pid, @Param("vid") int vid, @Param("score") int score);
    public double getVscore(int vid);
    public List<Discuss> getAllWords(int vid);
    public List<Video> getMyStar(int pid);       //获取我所有的收藏
    public void eva(Discuss discuss);

//    王晏
public void add(Video video);
    public void update(Video video);
    public List<Video> findAll();
    public void delete(int id);
    public Video findById(int id);
    public List<Video> findByType(int id);
    public List<Video> search(@Param(value = "src") String src);

}
