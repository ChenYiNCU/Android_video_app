package com.video.controller;

import com.pojo.ResultDTO;
import com.util.UploadUtil;
import com.video.biz.VideoBiz;
import com.video.entity.Discuss;
import com.video.entity.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("video")
public class VideoController {
    @Autowired
    private VideoBiz videoBiz;
    @RequestMapping(value = "/findVideoById")
    @ResponseBody
    public Video findVideoById(int vid){
        System.out.println(vid);
        Video v= videoBiz.findVideoById(vid);
        System.out.println(v);
        return v;
    }
    @RequestMapping(value = "/isStar")
    @ResponseBody
    public boolean isStar(int pid,int vid){
        int num=0;
        num=videoBiz.isStar(pid, vid);
        if (num==1){
            return true;     //已经收藏了
        }else{
            return false;   //未收藏
        }
    }
    @RequestMapping(value = "star")
    @ResponseBody
    public void star(int pid,int vid){
        videoBiz.star(pid, vid);
    }
    @RequestMapping(value = "noStar")
    @ResponseBody
    public void noStar(int pid,int vid){
        videoBiz.noStar(pid, vid);
    }
    @RequestMapping(value = "getMyscore")
    @ResponseBody
    public int getMyscore(int pid,int vid){
       int score=0;
       score=videoBiz.getMyscore(pid, vid);
       return score;

    }
    @RequestMapping(value = "setMyscore")
    @ResponseBody
    public void setMyscore(int pid,int vid,int score){
        System.out.println("pid:"+pid+" vid:"+vid+"score:"+score);
        if (videoBiz.getMyscore(pid, vid)>0){
//更新分数
             videoBiz.updateMyscore(pid, vid, score);
        }else{
            //新建
            videoBiz.setMyscore(pid, vid, score);
        }
    }
    @RequestMapping(value = "getVscore")
    @ResponseBody
    public String getVscore(int vid){                //得到电影的平均分
        double vscore= videoBiz.getVscore(vid);
        DecimalFormat df = new DecimalFormat("0.0");
        System.out.println(vscore);
        //返回的是保留两位小数后的字符串
        return df.format(vscore);
    }
    @RequestMapping(value = "/getAllWords")
    @ResponseBody
    public ResultDTO<Discuss> getAllWords(int vid)throws Exception{

        ResultDTO<Discuss> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("所有评论");
        List<Discuss> list=new ArrayList<Discuss>();
        list=videoBiz.getAllWords(vid);           //得到所有的评论
        VideoResultDTO.setDatas(list);
        return VideoResultDTO;
    }
    @RequestMapping(value = "eva")
    @ResponseBody
    public ResultDTO<Discuss> eva(@RequestBody Discuss discuss)throws Exception{
        ResultDTO<Discuss> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("评论成功");
        videoBiz.eva(discuss);    //保存到数据库
//        System.out.println("");
        return VideoResultDTO;
    }
    @RequestMapping(value = "getMyStar")
    @ResponseBody
    public ResultDTO<Video> getMyStar(int pid){
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("所有收藏");
        List<Video> list=new ArrayList<Video>();
        list=videoBiz.getMyStar(pid);           //得到所有的收藏
        System.out.println(list);
        VideoResultDTO.setDatas(list);
        return VideoResultDTO;
    }

//    王晏
    @RequestMapping(value = "/add")
    @ResponseBody
    public ResultDTO<Video> add(@RequestBody Video video)throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("添加成功");
        videoBiz.add(video);
        System.out.println("");
        return VideoResultDTO;
    }

    @RequestMapping(value = "/update")
    @ResponseBody
    public ResultDTO<Video> update(@RequestBody Video video)throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("修改成功");
        videoBiz.update(video);
        System.out.println("");
        return VideoResultDTO;
    }

    @RequestMapping(value = "/findAll")
    @ResponseBody
    public ResultDTO<Video> findAll()throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("添加成功");
        System.out.println("查找所有");
        List<Video> list=new ArrayList<Video>();
        list=videoBiz.findAll();
        VideoResultDTO.setDatas(list);
        return VideoResultDTO;
    }

    @RequestMapping(value = "/delete")
    @ResponseBody
    public ResultDTO<Video> delete(@RequestBody Video video)throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("删除成功");
        videoBiz.delete(video.getVid());
        return VideoResultDTO;
    }

    @RequestMapping(value = "/findById")
    @ResponseBody
    public ResultDTO<Video> findById(@RequestBody Video video)throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        Video video1=new Video();
        video1=videoBiz.findById(video.getVid());
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("查找成功");
        VideoResultDTO.setData(video1);
        return VideoResultDTO;
    }

    @RequestMapping(value = "/findByType")
    @ResponseBody
    public ResultDTO<Video> findByType(@RequestBody Video video)throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("添加成功");
        VideoResultDTO.setCode(1001);
        VideoResultDTO.setMsg("添加成功");
        List<Video> list=new ArrayList<Video>();
        list=videoBiz.findByType(video.getVtype().getTid());
        VideoResultDTO.setDatas(list);
        return VideoResultDTO;
    }

    @RequestMapping(value = "/search")
    @ResponseBody
    public ResultDTO<Video> search(@RequestBody Video video)throws Exception{
        ResultDTO<Video> VideoResultDTO = new ResultDTO<>();
        List<Video> list=new ArrayList<Video>();
        list=videoBiz.search(video.getVname());
        VideoResultDTO.setDatas(list);
        return VideoResultDTO;
    }

//    @RequestMapping(value = "/search")
//    @ResponseBody
//    public List<Video> search(String src){
//        List<Video> list=new ArrayList<Video>();
//        list=videoBiz.search(src);
//        return list;
//    }

    @PostMapping("/uploadVideo")
    @ResponseBody
    public ResultDTO<Video> uploadVideo(MultipartFile file, HttpServletRequest request)throws Exception{
        System.out.println("?");
        String ViedeoUrl = UploadUtil.uploadOneFile(file,"F://upload//videoplayer//",request,"test");
        ResultDTO<Video> userResultDTO = new ResultDTO<>();
        userResultDTO.setMsg(ViedeoUrl);
        System.out.println("?");
        return userResultDTO;
    }

}
